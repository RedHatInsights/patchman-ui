/bin/ls: cannot access '/etc/nova/migration': No such file or directory
/bin/ls: cannot access '/etc/pki/ovirt-vmconsole': No such file or directory
/bin/ls: cannot access '/etc/watchdog.d/': No such file or directory
/etc:
total 1320
drwxr-xr-x. 121   0   0   8192 Sep 12 04:30 .
dr-xr-xr-x.  17   0   0    224 Oct 31  2020 ..
drwxr-xr-x.   3   0   0     26 Jan 11  2023 .java
-rw-------.   1   0   0      0 Oct 31  2020 .pwd.lock
-rw-r--r--.   1   0   0    208 Oct 31  2020 .updated
-rw-r--r--.   1   0   0   4536 Apr 14  2020 DIR_COLORS
-rw-r--r--.   1   0   0   5214 Apr 14  2020 DIR_COLORS.256color
-rw-r--r--.   1   0   0   4618 Apr 14  2020 DIR_COLORS.lightbgcolor
-rw-r--r--.   1   0   0     94 Aug 12  2018 GREP_COLORS
drwxr-xr-x.   7   0   0    134 Oct 31  2020 NetworkManager
drwxr-xr-x.   2   0   0     48 Oct 31  2020 PackageKit
drwxr-xr-x.   6   0   0     70 Oct 31  2020 X11
-rw-r--r--.   1   0   0     16 Oct 31  2020 adjtime
-rw-r--r--.   1   0   0   1529 Apr 15  2020 aliases
drwxr-xr-x.   2   0   0   4096 Jan 11  2023 alternatives
-rw-r--r--.   1   0   0    541 Jun 12  2019 anacrontab
drwxr-xr-x.   3   0   0     51 Oct 19  2021 ansible
-rw-r--r--.   1   0   0    391 Dec 13  2018 ant.conf
drwxr-xr-x.   2   0   0      6 Dec 13  2018 ant.d
-rw-r--r--.   1   0   0     55 Jul  8  2022 asound.conf
drwxr-x---.   4   0   0    100 Oct 31  2020 audit
drwxr-xr-x.   3   0   0    228 Oct 31  2020 authselect
drwxr-xr-x.   2   0   0    111 Jan 11  2023 bash_completion.d
-rw-r--r--.   1   0   0   3019 Apr 15  2020 bashrc
-rw-r--r--.   1   0   0    429 Jul 24  2019 bindresvport.blacklist
drwxr-xr-x.   2   0   0      6 Oct  7  2020 binfmt.d
drwxr-xr-x.   3   0   0     59 Jan 11  2023 candlepin
drwxr-xr-x.   2   0   0      6 Apr 17  2020 chkconfig.d
-rw-r--r--.   1   0   0   1083 May 10  2019 chrony.conf
-rw-r-----.   1   0 989    540 May 10  2019 chrony.keys
drwxr-xr-x.   2   0   0     26 Oct 31  2020 cifs-utils
drwxr-xr-x.   4   0   0     59 Oct 31  2020 cloud
drwxr-xr-x.   3   0   0     19 Sep 12 05:14 cni
drwxr-xr-x.   4   0   0     42 Oct 31  2020 cockpit
drwxr-xr-x.   6   0   0    139 Mar  9  2022 containers
drwxr-xr-x.   2   0   0    108 Jan 11  2023 cron.d
drwxr-xr-x.   2   0   0     23 Oct 31  2020 cron.daily
-rw-r--r--.   1   0   0      0 Jun 12  2019 cron.deny
drwxr-xr-x.   2   0   0     22 Oct 31  2020 cron.hourly
drwxr-xr-x.   2   0   0      6 Aug 12  2018 cron.monthly
drwxr-xr-x.   2   0   0      6 Aug 12  2018 cron.weekly
-rw-r--r--.   1   0   0    451 Aug 12  2018 crontab
drwxr-xr-x.   6   0   0     81 Oct 31  2020 crypto-policies
-rw-------.   1   0   0      0 Oct 31  2020 crypttab
-rw-r--r--.   1   0   0   1629 Apr 15  2020 csh.cshrc
-rw-r--r--.   1   0   0   1078 Apr 15  2020 csh.login
drwxr-xr-x.   4   0   0     78 Oct 31  2020 dbus-1
drwxr-xr-x.   4   0   0     31 Jan 11  2023 dconf
drwxr-xr-x.   2   0   0     33 Oct 31  2020 default
drwxr-xr-x.   2   0   0     23 Oct 31  2020 depmod.d
drwxr-x---.   3   0   0     45 Oct 31  2020 dhcp
drwxr-xr-x.   8   0   0    128 Oct 31  2020 dnf
-rw-r--r--.   1   0   0    117 Aug  4  2020 dracut.conf
drwxr-xr-x.   2   0   0      6 Aug  4  2020 dracut.conf.d
-rw-r--r--.   1   0   0      0 Apr 15  2020 environment
-rw-r--r--.   1   0   0   1362 Aug 15  2020 ethertypes
-rw-r--r--.   1   0   0      0 Sep 10  2018 exports
drwxr-xr-x.   2   0   0      6 Jun 10  2020 exports.d
lrwxrwxrwx.   1   0   0     56 Aug 16  2019 favicon.png -> /usr/share/icons/hicolor/16x16/apps/fedora-logo-icon.png
-rw-r--r--.   1   0   0     66 Sep 10  2018 filesystems
drwxr-x---.   3   0   0     19 Oct 31  2020 firewalld
drwxr-xr-x.   3   0   0     38 Oct 31  2020 fonts
drwxr-xr-x.   4   0   0    193 Jan 11  2023 foreman
drwxr-xr-x.   3   0   0     50 Jan 11  2023 foreman-installer
drwxr-x---.   2   0   0     34 Jan 11  2023 foreman-maintain
drwxr-xr-x.   3   0   0    224 Jan 11  2023 foreman-proxy
-rw-r--r--.   1   0   0    534 Oct 31  2020 fstab
-rw-r--r--.   1   0   0     38 Nov 16  2018 fuse.conf
drwxr-xr-x.   2   0   0      6 Apr  6  2022 galaxy-importer
drwxr-xr-x.   7   0   0    107 Jan 11  2023 gconf
drwxr-xr-x.   2   0   0     25 Oct 31  2020 gcrypt
-rw-r--r--.   1   0   0    265 May 24  2022 gdbinit
drwxr-xr-x.   2   0   0      6 May 24  2022 gdbinit.d
drwxr-xr-x.   2   0   0      6 May  4  2020 gnupg
drwxr-xr-x.   4   0   0     40 Oct 31  2020 groff
-rw-r--r--.   1   0   0    826 Jan 11  2023 group
-rw-r--r--.   1   0   0    813 Jan 11  2023 group-
drwx------.   2   0   0    288 Oct 31  2020 grub.d
lrwxrwxrwx.   1   0   0     31 Aug 31  2020 grub2-efi.cfg -> ../boot/efi/EFI/redhat/grub.cfg
lrwxrwxrwx.   1   0   0     22 Aug 31  2020 grub2.cfg -> ../boot/grub2/grub.cfg
----------.   1   0   0    669 Jan 11  2023 gshadow
----------.   1   0   0    659 Jan 11  2023 gshadow-
drwxr-xr-x.   3   0   0     20 Oct 31  2020 gss
drwxr-xr-x.   2   0   0     79 Oct 31  2020 gssproxy
drwxr-xr-x.   3   0   0     49 Jan 11  2023 hammer
-rw-r--r--.   1   0   0      9 Sep 10  2018 host.conf
-rw-r--r--.   1   0   0     22 Sep 12 04:30 hostname
-rw-r--r--.   1   0   0    158 Jan 13  2023 hosts
drwxr-xr-x.   5   0   0    105 Jan 11  2023 httpd
-rw-r--r--.   1   0   0   4849 Jun 10  2020 idmapd.conf
lrwxrwxrwx.   1   0   0     11 Apr 17  2020 init.d -> rc.d/init.d
-rw-r--r--.   1   0   0    490 Oct  7  2020 inittab
-rw-r--r--.   1   0   0    942 Sep 10  2018 inputrc
drwxr-xr-x.   2   0   0   4096 Sep 12 05:14 insights-client
drwxr-xr-x.   2   0   0    159 Oct 31  2020 iproute2
-rw-r--r--.   1   0   0     23 Sep 23  2020 issue
drwxr-xr-x.   2   0   0     27 Oct 31  2020 issue.d
-rw-r--r--.   1   0   0     22 Sep 23  2020 issue.net
drwxr-xr-x.   5   0   0    131 Jan 11  2023 java
drwxr-xr-x.   2   0   0      6 Dec 13  2018 jvm
drwxr-xr-x.   2   0   0      6 Dec 13  2018 jvm-commmon
drwxr-xr-x.   4   0   0     33 Oct 31  2020 kdump
-rw-r--r--.   1   0   0   8484 Oct 31  2020 kdump.conf
drwxr-xr-x.   4   0   0     41 Oct 31  2020 kernel
-rw-r--r--.   1   0   0    812 Aug  4  2020 krb5.conf
drwxr-xr-x.   2   0   0     55 Oct 31  2020 krb5.conf.d
-rw-r--r--.   1   0   0  34137 Jan 11  2023 ld.so.cache
-rw-r--r--.   1   0   0     28 Aug  1  2018 ld.so.conf
drwxr-xr-x.   2   0   0     84 Oct 31  2020 ld.so.conf.d
-rw-r-----.   1   0   0    191 Nov  4  2019 libaudit.conf
drwxr-xr-x.   2   0   0     35 Oct 31  2020 libnl
drwxr-xr-x.   6   0   0     70 Oct 31  2020 libreport
drwxr-xr-x.   2   0   0     62 Oct 31  2020 libssh
-rw-r--r--.   1   0   0   2391 Jul 23  2015 libuser.conf
drwxr-xr-x.   2   0   0     52 Jan 11  2023 libvirt
-rw-r--r--.   1   0   0     17 Sep 12 04:30 locale.conf
lrwxrwxrwx.   1   0   0     38 Oct 31  2020 localtime -> ../usr/share/zoneinfo/America/New_York
-rw-r--r--.   1   0   0   2512 Aug  7  2020 login.defs
-rw-r--r--.   1   0   0    438 Feb 19  2018 logrotate.conf
drwxr-xr-x.   2   0   0    250 Jan 11  2023 logrotate.d
-r--r--r--.   1   0   0     33 Oct 19  2021 machine-id
-rw-r--r--.   1   0   0    111 Jun 22  2020 magic
-rw-r--r--.   1   0   0    272 May 11  2017 mailcap
-rw-r--r--.   1   0   0   5122 Aug 19  2020 makedumpfile.conf.sample
-rw-r--r--.   1   0   0   5165 Nov  7  2018 man_db.conf
drwxr-xr-x.   3   0   0     32 Oct 31  2020 microcode_ctl
-rw-r--r--.   1   0   0  60352 May 11  2017 mime.types
-rw-r--r--.   1   0   0   1108 Jun  8  2020 mke2fs.conf
drwxr-xr-x.   2   0   0     42 Oct 31  2020 modprobe.d
drwxr-xr-x.   2   0   0      6 Oct  7  2020 modules-load.d
-rw-r--r--.   1   0   0     90 Jan 13  2023 motd
drwxr-xr-x.   2   0   0     44 Sep 12 05:14 motd.d
lrwxrwxrwx.   1   0   0     19 Oct 31  2020 mtab -> ../proc/self/mounts
-rw-r--r--.   1   0   0   2620 Aug 12  2018 mtools.conf
-rw-r--r--.   1   0   0    767 Jul 24  2019 netconfig
-rw-r--r--.   1   0   0     58 Sep 10  2018 networks
-rw-r--r--.   1   0   0   1098 Jun 10  2020 nfs.conf
-rw-r--r--.   1   0   0   3606 Jun 10  2020 nfsmount.conf
drwx------.   3   0   0     66 Mar  9  2022 nftables
lrwxrwxrwx.   1   0   0     29 Oct 31  2020 nsswitch.conf -> /etc/authselect/nsswitch.conf
-rw-r--r--.   1   0   0   2197 Jun 10  2020 nsswitch.conf.bak
drwxr-xr-x.   2   0   0      6 Oct  8  2020 oddjob
-rw-r--r--.   1   0   0   4922 Oct  8  2020 oddjobd.conf
drwxr-xr-x.   2   0   0     70 Oct 31  2020 oddjobd.conf.d
drwxr-xr-x.   3   0   0     36 Oct 31  2020 openldap
drwxr-xr-x.   2   0   0      6 Apr 23  2020 opt
lrwxrwxrwx.   1   0   0     22 Sep 23  2020 os-release -> ..//usr/lib/os-release
drwxr-xr-x.   2   0   0   4096 Jan 11  2023 pam.d
-rw-r-----.   1   0   0   1375 Oct  7  2022 passenger-recycler.yaml
-rw-r--r--.   1   0   0   2197 Jan 11  2023 passwd
-rw-r--r--.   1   0   0   2197 Sep 12 04:30 passwd-
drwxr-xr-x.  25   0   0   4096 Apr  5  2022 pcp
-rw-r--r--.   1   0   0   7160 Aug 28  2021 pcp.conf
-rw-r--r--.   1   0   0   6662 Aug 28  2021 pcp.env
drwxr-xr-x.   3   0   0     21 Oct 31  2020 pkcs11
drwxr-xr-x.  15   0   0    215 Jan 11  2023 pki
drwxr-xr-x.   5   0   0     52 Oct 31  2020 pm
drwxr-xr-x.   5   0   0     72 Oct 31  2020 polkit-1
drwxr-xr-x.   2   0   0      6 Aug 12  2018 popt.d
drwxr-xr-x.   4   0   0   4096 Jan 11  2023 postfix
drwxr-xr-x.   3   0   0     21 Jan 11  2023 postgresql-setup
drwxr-xr-x.   2   0   0     24 Oct 31  2020 prelink.conf.d
-rw-r--r--.   1   0   0    233 Sep 10  2018 printcap
-rw-r--r--.   1   0   0   2123 Apr 15  2020 profile
drwxr-xr-x.   2   0   0   4096 Jan 11  2023 profile.d
-rw-r--r--.   1   0   0   6568 Sep 10  2018 protocols
drwxr-xr-x.   3   0   0     38 Jan 11  2023 pulp
drwxr-xr-x.   5   0   0     49 Jan 11  2023 puppetlabs
drwxr-xr-x.   3   0   0     50 Oct 31  2020 qemu-ga
drwxr-xr-x.  10   0   0    127 Jul 24  2020 rc.d
lrwxrwxrwx.   1   0   0     13 Oct  7  2020 rc.local -> rc.d/rc.local
lrwxrwxrwx.   1   0   0     10 Apr 17  2020 rc0.d -> rc.d/rc0.d
lrwxrwxrwx.   1   0   0     10 Apr 17  2020 rc1.d -> rc.d/rc1.d
lrwxrwxrwx.   1   0   0     10 Apr 17  2020 rc2.d -> rc.d/rc2.d
lrwxrwxrwx.   1   0   0     10 Apr 17  2020 rc3.d -> rc.d/rc3.d
lrwxrwxrwx.   1   0   0     10 Apr 17  2020 rc4.d -> rc.d/rc4.d
lrwxrwxrwx.   1   0   0     10 Apr 17  2020 rc5.d -> rc.d/rc5.d
lrwxrwxrwx.   1   0   0     10 Apr 17  2020 rc6.d -> rc.d/rc6.d
-rw-r--r--.   1   0   0     45 Sep 23  2020 redhat-release
drwxr-xr-x.   2 985   0      6 Jan 11  2023 redis
-rw-r-----.   1 985   0   9746 Oct 11  2021 redis-sentinel.conf
-rw-r--r--.   1 985   0  33481 Jan 11  2023 redis.conf
-rw-r--r--.   1 985   0  33481 Jan 11  2023 redis.conf.puppet
-rw-r--r--.   1   0   0   1787 Aug 12  2018 request-key.conf
drwxr-xr-x.   2   0   0     30 Oct 31  2020 request-key.d
-rw-r--r--.   1   0   0    117 Sep 12 04:30 resolv.conf
drwxr-xr-x.   6   0   0    125 Sep 12 05:12 rhsm
-rw-r--r--.   1   0   0   1634 Aug  1  2018 rpc
drwxr-xr-x.   2   0   0     47 Jan 11  2023 rpm
-rw-r--r--.   1   0   0   3186 Jun 18  2020 rsyslog.conf
drwxr-xr-x.   2   0   0     31 Oct 31  2020 rsyslog.d
drwxr-xr-x.   2   0   0     35 Oct 31  2020 rwtab.d
drwxr-xr-x.   2   0   0     41 Jan 11  2023 sasl2
drwxr-xr-x.   7   0   0   4096 Oct 31  2020 security
drwxr-xr-x.   3   0   0     57 Jan 11  2023 selinux
-rw-r--r--.   1   0   0 692252 Apr 15  2020 services
-rw-r--r--.   1   0   0    216 Jul 15  2022 sestatus.conf
drwxr-xr-x.   2   0   0     33 Oct 31  2020 setroubleshoot
drwxr-xr-x.   3   0   0     21 Jan 11  2023 sgml
----------.   1   0   0   1209 Sep 12 04:30 shadow
----------.   1   0   0   1207 Sep 12 04:30 shadow-
-rw-r--r--.   1   0   0     44 Sep 10  2018 shells
drwxr-xr-x.   2   0   0     62 Oct 31  2020 skel
-rw-r--r--.   1   0   0    138 Aug 19  2020 sos.conf
drwxr-xr-x.   3   0   0    245 Sep 12 04:31 ssh
drwxr-xr-x.   2   0   0     19 Jan 11  2023 ssl
drwx------.   4 996 993     31 Oct 31  2020 sssd
-rw-r--r--.   1   0   0     24 Oct 19  2021 subgid
-rw-r--r--.   1   0   0      0 Sep 10  2018 subgid-
-rw-r--r--.   1   0   0     24 Oct 19  2021 subuid
-rw-r--r--.   1   0   0      0 Sep 10  2018 subuid-
-rw-r-----.   1   0   0   3181 Apr 28  2020 sudo-ldap.conf
-rw-r-----.   1   0   0   1786 Apr 28  2020 sudo.conf
-r--r-----.   1   0   0   4363 Jan 13  2023 sudoers
drwxr-x---.   2   0   0     33 Oct 19  2021 sudoers.d
drwxr-xr-x.   3   0   0     24 Oct 31  2020 swid
drwxr-xr-x.   5   0   0   4096 Jan 11  2023 sysconfig
-rw-r--r--.   1   0   0    449 Oct  7  2020 sysctl.conf
drwxr-xr-x.   2   0   0     28 Oct 31  2020 sysctl.d
lrwxrwxrwx.   1   0   0     14 Sep 23  2020 system-release -> redhat-release
-rw-r--r--.   1   0   0     38 Sep 23  2020 system-release-cpe
drwxr-xr-x.   4   0   0    150 Oct 31  2020 systemd
-rw-------.   1  59  59   7046 Jun 10  2019 tcsd.conf
drwxr-xr-x.   2   0   0      6 Jan 16  2019 terminfo
drwxr-xr-x.   2   0   0      6 Oct  7  2020 tmpfiles.d
drwxr-xr-x.   4   0  91   4096 Jan 11  2023 tomcat
drwxr-xr-x.   3   0   0    136 Oct 31  2020 tuned
drwxr-xr-x.   4   0   0     68 Oct 19  2021 udev
drwxr-xr-x.   2   0   0     45 Oct 31  2020 unbound
-rw-r--r--.   1   0   0     28 Oct 31  2020 vconsole.conf
-rw-r--r--.   1   0   0   1204 Jun  3  2020 virc
-rw-r--r--.   1   0   0   4925 Apr  3  2020 wgetrc
-rw-r--r--.   1   0   0    642 Dec  9  2016 xattr.conf
drwxr-xr-x.   4   0   0     38 Oct 31  2020 xdg
drwxr-xr-x.   2   0   0      6 Apr 23  2020 xinetd.d
drwxr-xr-x.   2   0   0     21 Jan 11  2023 xml
drwxr-xr-x.   2   0   0     57 Oct 31  2020 yum
lrwxrwxrwx.   1   0   0     12 Jul 29  2020 yum.conf -> dnf/dnf.conf
drwxr-xr-x.   2   0   0     25 Sep 12 05:06 yum.repos.d

/etc/cloud/cloud.cfg.d:
total 8
drwxr-xr-x. 2 0 0   42 Oct 31  2020 .
drwxr-xr-x. 4 0 0   59 Oct 31  2020 ..
-rw-r--r--. 1 0 0 2057 Dec 18  2019 05_logging.cfg
-rw-r--r--. 1 0 0  167 Dec 18  2019 README

/etc/pki/tls/certs:
total 4
drwxr-xr-x. 2 0 0   73 Jan 11  2023 .
drwxr-xr-x. 5 0 0  104 Jan 11  2023 ..
lrwxrwxrwx. 1 0 0   49 Jul 28  2022 ca-bundle.crt -> /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem
lrwxrwxrwx. 1 0 0   55 Jul 28  2022 ca-bundle.trust.crt -> /etc/pki/ca-trust/extracted/openssl/ca-bundle.trust.crt
-rw-r--r--. 1 0 0 2236 Jan 11  2023 postfix.pem

/etc/pki/tls/private:
total 4
drwxr-xr-x. 2 0 0   25 Jan 11  2023 .
drwxr-xr-x. 5 0 0  104 Jan 11  2023 ..
-rw-------. 1 0 0 3243 Jan 11  2023 postfix.key

/etc/rc.d/init.d:
total 24
drwxr-xr-x.  2 0 0    37 Oct 31  2020 .
drwxr-xr-x. 10 0 0   127 Jul 24  2020 ..
-rw-r--r--.  1 0 0  1161 Oct  7  2020 README
-rw-r--r--.  1 0 0 18434 Jul 24  2020 functions

/etc/selinux/targeted/policy:
total 8656
drwxr-xr-x. 2 0 0      23 Jan 11  2023 .
drwxr-xr-x. 5 0 0     133 Jan 11  2023 ..
-rw-r--r--. 1 0 0 8862728 Jan 11  2023 policy.31

/etc/sysconfig:
total 136
drwxr-xr-x.   5 0 0 4096 Jan 11  2023 .
drwxr-xr-x. 121 0 0 8192 Sep 12 04:30 ..
-rw-r--r--.   1 0 0  112 Oct 31  2020 anaconda
-rw-r--r--.   1 0 0   37 Oct 31  2020 authconfig
-rw-r--r--.   1 0 0   46 May 22  2019 chronyd
drwxr-xr-x.   2 0 0    6 Jul 24  2020 console
-rw-r--r--.   1 0 0  150 Oct 16  2020 cpupower
-rw-r--r--.   1 0 0  110 Jun 12  2019 crond
-rw-r--r--.   1 0 0   17 Oct 31  2020 firstboot
lrwxrwxrwx.   1 0 0   15 Aug 31  2020 grub -> ../default/grub
-rw-r--r--.   1 0 0  348 Jul 28  2022 htcacheclean
-rw-------.   1 0 0 2134 Aug 15  2020 ip6tables-config
-rw-------.   1 0 0 2116 Aug 15  2020 iptables-config
-rw-r--r--.   1 0 0  903 Jul 30  2019 irqbalance
-rw-r--r--.   1 0 0 1768 Aug 19  2020 kdump
-rw-r--r--.   1 0 0  180 Oct 31  2020 kernel
-rw-r--r--.   1 0 0  310 Nov  7  2018 man-db
drwxr-xr-x.   2 0 0    6 Jul 24  2020 modules
-rw-r--r--.   1 0 0  102 Sep 12 04:30 network
drwxr-xr-x.   2 0 0   42 Oct 19  2021 network-scripts
-rw-------.   1 0 0  364 Aug 20  2021 nftables.conf
-rw-r--r--.   1 0 0 1571 Aug 28  2021 pmcd
-rw-r--r--.   1 0 0  154 Aug 28  2021 pmfind
-rw-r--r--.   1 0 0  313 Aug 28  2021 pmie_timers
-rw-r--r--.   1 0 0 1124 Apr  5  2022 pmlogger
-rw-r--r--.   1 0 0 1248 Aug 28  2021 pmlogger_timers
-rw-r--r--.   1 0 0  454 Aug 28  2021 pmproxy
-rw-r--r--.   1 0 0   92 Oct 29  2021 puppet
-rw-r--r--.   1 0 0   87 Sep 22  2021 pxp-agent
-rw-r--r--.   1 0 0  911 Sep  8  2020 qemu-ga
-rw-r--r--.   1 0 0   73 Feb  6  2020 rpcbind
-rw-r--r--.   1 0 0  196 Jun 18  2020 rsyslog
-rw-r--r--.   1 0 0    0 Aug 12  2018 run-parts
-rw-r--r--.   1 0 0  429 May  7  2020 saslauthd
lrwxrwxrwx.   1 0 0   17 Oct 31  2020 selinux -> ../selinux/config
-rw-r-----.   1 0 0  591 Mar 27  2020 sshd
-rw-r--r--.   1 0 0  161 Oct 31  2020 sshd-permitrootlogin
-rw-r--r--.   1 0 0  490 Jun 24  2022 tomcat
