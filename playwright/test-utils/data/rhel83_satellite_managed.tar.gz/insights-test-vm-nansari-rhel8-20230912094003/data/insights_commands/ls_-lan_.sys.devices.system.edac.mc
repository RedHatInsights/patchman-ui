total 0
drwxr-xr-x. 3 0 0    0 Sep 12 04:30 .
drwxr-xr-x. 4 0 0    0 Sep 12 04:30 ..
drwxr-xr-x. 2 0 0    0 Sep 12 05:14 power
lrwxrwxrwx. 1 0 0    0 Sep 12 04:30 subsystem -> ../../../../bus/edac
-rw-r--r--. 1 0 0 4096 Sep 12 04:30 uevent
